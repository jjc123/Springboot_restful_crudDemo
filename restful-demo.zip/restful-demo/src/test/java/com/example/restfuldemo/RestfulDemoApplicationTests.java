package com.example.restfuldemo;

import com.example.restfuldemo.dao.DepartmentDao;
import com.example.restfuldemo.dao.EmployeeDao;
import com.example.restfuldemo.entities.Department;
import com.example.restfuldemo.entities.Employee;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.sql.DataSource;
import java.util.Collection;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RestfulDemoApplicationTests {

    @Autowired
    DepartmentDao departmentDao;
    @Autowired
    EmployeeDao employeeDao;
    @Test
    public void contextLoads() {
        Collection<Department> departments = departmentDao.getDepartments();
        for(Department temp:departments){
            System.out.println(temp);
        }
    }

    @Test
    public void findAll(){
        //System.out.println(departmentDao.getDepartment(2));
        Collection<Employee> all = employeeDao.getAll();
        for(Employee temp:all){
            System.out.println(temp);
        }
    }

}
