package com.example.restfuldemo.dao;

import com.example.restfuldemo.entities.Employee;
import org.apache.ibatis.annotations.Param;

import java.util.Collection;

/**
 * @ClassName:
 * @Author:
 * @Description:
 * @Date:
 * @Version:
 */
public interface EmployeeDao {
    Collection<Employee> getAll();
    int save(Employee employee);
    Employee get(@Param("id") Integer id);
    int delete(@Param("id") Integer id);
    int update(Employee employee);
}
