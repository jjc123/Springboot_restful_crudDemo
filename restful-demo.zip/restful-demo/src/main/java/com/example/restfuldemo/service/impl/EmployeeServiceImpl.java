package com.example.restfuldemo.service.impl;

import com.example.restfuldemo.dao.DepartmentDao;
import com.example.restfuldemo.dao.EmployeeDao;
import com.example.restfuldemo.entities.Employee;
import com.example.restfuldemo.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * @ClassName:
 * @Author:
 * @Description:
 * @Date:
 * @Version:
 */
@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    EmployeeDao employeeDao;
    @Override
    public Collection<Employee> getAll() {
        return employeeDao.getAll();
    }

    @Override
    public int save(Employee employee) {
        return employeeDao.save(employee);
    }

    @Override
    public Employee get(Integer id) {
        return employeeDao.get(id);
    }

    @Override
    public int delete(Integer id) {
        return employeeDao.delete(id);
    }

    @Override
    public int update(Employee employee) {
        return employeeDao.update(employee);
    }
}
