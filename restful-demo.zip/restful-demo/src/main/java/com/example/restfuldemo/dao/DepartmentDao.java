package com.example.restfuldemo.dao;

import com.example.restfuldemo.entities.Department;
import org.apache.ibatis.annotations.Param;

import java.util.Collection;

/**
 * @ClassName:
 * @Author:
 * @Description:
 * @Date:
 * @Version:
 */
public interface DepartmentDao {
    Collection<Department> getDepartments();
    Department getDepartment(@Param("id")Integer id);
}
