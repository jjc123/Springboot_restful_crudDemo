package com.example.restfuldemo.service;

import com.example.restfuldemo.entities.Employee;

import java.util.Collection;

/**
 * @ClassName:
 * @Author:
 * @Description:
 * @Date:
 * @Version:
 */
public interface EmployeeService {
    Collection<Employee> getAll();
    int save(Employee employee);
    Employee get(Integer id);
    int delete(Integer id);
    int update(Employee employee);
}
