package com.example.restfuldemo.service.impl;

import com.example.restfuldemo.dao.DepartmentDao;
import com.example.restfuldemo.entities.Department;
import com.example.restfuldemo.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * @ClassName:
 * @Author:
 * @Description:
 * @Date:
 * @Version:
 */
@Service("departmentService")
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired
    DepartmentDao departmentDao;
    @Override
    public Collection<Department> getDepartments() {
        return departmentDao.getDepartments();
    }
}
