package com.example.restfuldemo.config;

import com.example.restfuldemo.handler.LoginHandlerInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

/**
 *
 */
@Configuration
public class MyConfig implements WebMvcConfigurer {

    /**
     * springboot2默认是拦截静态资源的，这里需要给静态资源进行地址映射，
     * 注意如果是"classpath:"会去resources路径下寻找，如果不加classpath无法地址映射
     * @param registry
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/static/**").addResourceLocations("classpath:/static/");
    }

    /**
     * 映射控制层地址，这里不需要加classpath
     * @param registry
     */
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/").setViewName("index");
    }

    @Bean
    public WebMvcConfigurer hello(){
        WebMvcConfigurer webMvcConfigurer = new WebMvcConfigurerAdapter() {
            @Override
            public void addViewControllers(ViewControllerRegistry registry) {
                registry.addViewController("/index").setViewName("index");
                registry.addViewController("/index.html").setViewName("index");
                registry.addViewController("/main.html").setViewName("dashboard");
            }
        };
        return webMvcConfigurer;
    }

    /**
     * 添加拦截器，拦截所有地址，但是过滤指定地址
     * @param registry
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new LoginHandlerInterceptor()).addPathPatterns("/**").excludePathPatterns("/","/index"
                ,"/index.html","/login","/static/**");
    }
}