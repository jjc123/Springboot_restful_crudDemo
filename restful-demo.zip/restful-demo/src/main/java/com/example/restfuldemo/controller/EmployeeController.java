package com.example.restfuldemo.controller;

import com.example.restfuldemo.entities.Department;
import com.example.restfuldemo.entities.Employee;
import com.example.restfuldemo.service.DepartmentService;
import com.example.restfuldemo.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.List;
import java.util.Map;

@Controller
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;
    @Autowired
    DepartmentService departmentService;

    @GetMapping(value = "/emps")
    public String getAll(Model model){
        Collection<Employee> all = employeeService.getAll();
        model.addAttribute("emps",all);
        return "emps/list";
    }
    @GetMapping(value = "/emp")
    public String toAdd(Model model){
        Collection<Department> departments = departmentService.getDepartments();
        model.addAttribute("deps",departments);
        return "emps/toadd";
    }

    @PostMapping(value = "/emp")
    public String addEmp(Employee employee){
        int count = employeeService.save(employee);
        int key = employee.getId();
        System.out.println("插入的人员数量:"+count);
        System.out.println("插入的人员id:"+key);
        //重定向，这里/emps是从上面的控制类进入,而不是资源
        return "redirect:/emps";
    }
    @GetMapping(value = "/emp/{id}")
    public String toChange(@PathVariable("id") Integer id,Model model){
        Employee employee = employeeService.get(id);
        model.addAttribute("emp",employee);

        Collection<Department> departments = departmentService.getDepartments();
        model.addAttribute("deps",departments);
        return "emps/toadd";
    }

    @PutMapping(value = "/emp")
    public String change(Employee employee){
        int count = employeeService.update(employee);
        System.out.println("修改的人员数量:"+count);
        return "redirect:/emps";
    }
    @DeleteMapping(value = "/emp/{id}")
    public String delete(@PathVariable("id") Integer id){
        int delete = employeeService.delete(id);
        System.out.println("删除的人员数量:"+delete);
        return "redirect:/emps";
    }
}
