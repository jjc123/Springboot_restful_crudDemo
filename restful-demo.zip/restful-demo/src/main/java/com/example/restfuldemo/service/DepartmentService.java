package com.example.restfuldemo.service;

import com.example.restfuldemo.entities.Department;

import java.util.Collection;

/**
 * @ClassName:
 * @Author:
 * @Description:
 * @Date:
 * @Version:
 */
public interface DepartmentService {
    Collection<Department> getDepartments();
}
