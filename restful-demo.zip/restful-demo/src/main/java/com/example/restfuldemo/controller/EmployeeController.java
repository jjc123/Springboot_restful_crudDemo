package com.example.restfuldemo.controller;

import com.example.restfuldemo.dao.DepartmentDao;
import com.example.restfuldemo.dao.EmployeeDao;
import com.example.restfuldemo.entities.Department;
import com.example.restfuldemo.entities.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@Controller
public class EmployeeController {

    @Autowired
    EmployeeDao employeeDao;
    @Autowired
    DepartmentDao departmentDao;

    @GetMapping(value = "/emps")
    public String getAll(Model model){
        Collection<Employee> all = employeeDao.getAll();
        model.addAttribute("emps",all);
        return "emps/list";
    }
    @GetMapping(value = "/emp")
    public String toAdd(Model model){
        Collection<Department> departments = departmentDao.getDepartments();
        model.addAttribute("deps",departments);
        return "emps/toadd";
    }
    @PostMapping(value = "/emp")
    public String addEmp(Employee employee){
        System.out.println(employee);
        employeeDao.save(employee);
        //重定向，这里/emps是从上面的控制类进入
        return "redirect:/emps";
    }
    @GetMapping(value = "/emp/{id}")
    public String toChange(@PathVariable("id") Integer id,Model model){
        System.out.println(id);
        Employee employee = employeeDao.get(id);
        model.addAttribute("emp",employee);

        Collection<Department> departments = departmentDao.getDepartments();
        model.addAttribute("deps",departments);
        return "emps/toadd";
    }
    @PutMapping(value = "/emp")
    public String change(Employee employee){
        employeeDao.save(employee);
        return "redirect:/emps";
    }
    @DeleteMapping(value = "/emp/{id}")
    public String delete(@PathVariable("id") Integer id){
        employeeDao.delete(id);

        return "redirect:/emps";
    }

}
