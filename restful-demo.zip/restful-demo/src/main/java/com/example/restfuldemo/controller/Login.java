package com.example.restfuldemo.controller;

import org.springframework.boot.web.servlet.server.Session;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.util.StringUtils;

import javax.servlet.http.HttpSession;
import java.util.Map;

@Controller
public class Login {
    //@RequestMapping(value = "/login",method = RequestMethod.POST)
    //@GetMapping
    @PostMapping(value = "/login")
    public String login(@RequestParam("username") String username, @RequestParam("userpassword") String userpassword,
                        Map<String,Object> map, HttpSession session){
        if(!StringUtils.isEmpty(username) &&"123456".equals(userpassword)){
            session.setAttribute("user",username);
            return "redirect:/main.html";
        }else{
            map.put("msg","用户密码错误");
            return "index";
        }
    }
}
